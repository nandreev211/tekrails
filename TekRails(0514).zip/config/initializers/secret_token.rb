# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
TekRails::Application.config.secret_token = '7f4b519fb15e3cc7a29163efb3ca09afc5c77992aa4922333530b2989591937d6d48b169ed68ce06395e6b6d0f6a7ce27f39c2d412d179e6f45d7b11c43a4761'
