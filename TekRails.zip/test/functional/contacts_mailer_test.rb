require 'test_helper'

class ContactsMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
