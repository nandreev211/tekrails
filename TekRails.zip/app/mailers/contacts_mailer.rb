class ContactsMailer < ActionMailer::Base
  default to: "n.andreev.211@gmail.com"

  def new_message(message)
    @message = message
    mail(:from => message.email, :body => "#{message.message}", :reply_to => message.email)
  end
end
